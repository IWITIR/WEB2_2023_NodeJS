# 생활코딩 Node.js 학습
+ 작동법
  + 필요조건 : node.js, md2, sanitize-html
1. web2_nodeJS_lifecoding 파일에서 shift+우클릭으로 powershell 열기
2. (NodeJS만 사용) node main.js 입력, ctrl+C로 중지
2. (pm2 사용) pm2 start main.js --watch --ignore-watch="data/*" --no-daemon, pm2 kill 혹은 pm2 stop main으로 중지
(--ignore-watch="data/*" -> data파일에 대한 변경시 의도치 않은 서버 재부팅 방지,
--no-daemon -> log까지 같이 켜줌)

3. locathost:3000으로 홈페이지 접근 가능

---
메인 파일 : main.js
템플릿 파일 (main.js에서 require) : lib/template.js
데이터 파일 : data/ 에 저장


(미사용)
nodeJS 파일 - nodeJS 기능 예제
syntax 파일 - JS 문법 예제
나머지 등등
---

## 자세한 내용은 생활코딩 WEB2 - Node.Js 참조
## https://opentutorials.org/course/3332
