module.exports = {
  id : 'egoing',
  password : '111111',
}

// http://localhost:3000/?id=../password.js -> readFile( 'web2_nodeJS_lifecoding/data/../password.js', ...)
// id and password is exposed without security code.
