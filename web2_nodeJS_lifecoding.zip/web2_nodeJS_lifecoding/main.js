var http = require('http');
var url = require('url'); // same statement as import url as url in python
var fs = require('fs');
var qs = require('querystring');
var template = require('./lib/template.js')
var path = require('path') // for security to stop hacking using id=../ etc
var sanitizeHtml = require('sanitize-html')

var app = http.createServer(function(request,response){
    var _url = request.url;
    var queryData = url.parse(_url, true).query;
    var pathname = url.parse(_url, true).pathname;

    // pathname means path(/...) string excluding queryString (?...)
    if (pathname === '/') { // call for get-page.
      if (queryData.id === undefined) { // homepage.

        fs.readdir('./data', function(error, filelist){
          var title = 'Welcome';
          var description = 'Hello, Node.js';

          var pageBody = template.body('show', title, description);
          var pageControl = template.control('home');

          var pageList = template.list(filelist);
          var html = template.html(title, pageList, pageBody, pageControl);

          response.writeHead(200); // 200 means server has successfully transmitted file.
          response.end(html);
        });

      } else { // sub-page.
        fs.readdir('./data', function(error, filelist){
          var filteredID = path.parse(queryData.id).base;
          fs.readFile(`data/${filteredID}`, 'utf-8', function(err, description) {

            // secure safe in output
            var sanitizedTitle = sanitizeHtml(filteredID);
            var sanitizedDescription = sanitizeHtml(description, { allowedTags : ['h1'] } );

            var pageBody = template.body('show', sanitizedTitle, sanitizedDescription);
            var pageControl = template.control('content', sanitizedTitle);

            var pageList = template.list(filelist);
            var html = template.html(sanitizedTitle, pageList, pageBody, pageControl);

            response.writeHead(200); // 200 means server has successfully transmitted file.
            response.end(html);
          });
        });
      }
    }
    else if (pathname === "/create") { // create interface page
      fs.readdir('./data', function(error, filelist){
        var title = 'WEB - create';

        var pageBody = template.body('create', title);
        var pageControl =  template.control('create');

        var pageList = template.list(filelist);
        var html = template.html(title, pageList, pageBody, pageControl);

        response.writeHead(200); // 200 means server has successfully transmitted file.
        response.end(html);
      });
    }
    else if (pathname === "/create_process") { // redirection page of create page.
      fs.readdir('./data', function(error, filelist){
        var body ='';

        // receive data
        request.on('data', function(data){
          body += data;
        });

        // receiving end, parsing data and save it to variable post
        request.on('end', function(){
          var post = qs.parse(body);
          var title = post.title;
          var filteredTitle = path.parse(title).base;
          var description = post.description;

          // checking if there is file of same name
          var isAlreadyExist = false;
          for (var i = 0; i < filelist.length; i++){
            if (filelist[i] === filteredTitle){
              isAlreadyExist = true;
            }
          }


          if (isAlreadyExist){
            response.writeHead(302, {location : '/create'}); // 302 means redirection.
            response.end(`<script>alert('failed!');</script>`); // i have no idea why alert() does not work
          } else {
            fs.writeFile(`data/${filteredTitle}`,`${description}`,'utf8',function(err){
              response.writeHead(302, {location : '/create'}); // 302 means redirection.
              response.end('success');
            });
          }
        });
      });
    }
    else if (pathname === "/update") { // ui page to create new page.
      fs.readdir('./data', function(error, filelist){
        var filteredID = path.parse(queryData.id).base;
        fs.readFile(`data/${filteredID}`, 'utf-8', function(err, description) {
          var title = filteredID;

          var pageBody = template.body('update', title, description);
          var pageControl = template.control('update', filteredID);

          var pageList = template.list(filelist);
          var html = template.html(title, pageList, pageBody, pageControl);

          response.writeHead(200); // 200 means server has successfully transmitted file.
          response.end(html);
        });
      });
    }
    else if (pathname === "/update_process") { // redirection page of create page.
      var body ='';

      // receive data
      request.on('data', function(data){
        body += data;
      });
      // receiving end, parsing data and save it to variable post
      request.on('end', function(){
        var post = qs.parse(body);
        var id = post.id;
        var filteredID = path.parse(id).base;
        var title = post.title;
        var filteredTitle = path.parse(title).base;
        var description = post.description;
        fs.rename(`data/${filteredID}`,`data/${filteredTitle}`,function(err){
          fs.writeFile(`data/${filteredTitle}`,`${description}`,function(err){
            response.writeHead(302, {location : `/?id=${filteredTitle}`}); // 302 means redirection.
            response.end('success');
          });
        });
      });
    }
    else if (pathname === "/delete_process"){
      var body ='';

      // receive data
      request.on('data', function(data){
        body += data;
      });

      // receiving end, parsing data and save it to variable post
      request.on('end', function(){
        var post = qs.parse(body);
        var id = post.id;
        var filteredID = path.parse(post.id).base;
        fs.unlink(`data/${filteredID}`, function(err){
          response.writeHead(302, {location : '/'}); // 404 : server failed to transmit file
          response.end('success');
        });
      });
    }
    else { // path is not / : invalid call
      response.writeHead(404); // 404 : server failed to transmit file
      response.end('Not Found');
    }



});
app.listen(3000);
