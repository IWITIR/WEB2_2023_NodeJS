var mPart = require('./mPart.js');

mPart.f();
