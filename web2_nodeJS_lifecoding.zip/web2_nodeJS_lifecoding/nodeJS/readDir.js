var testFolder = __dirname; // !! __dirname is special value that indicates folder which this file is included directly. in this case, nodeJS file.
var testFolder = './'; //  !! ./ means current directory (where node js is executed)
var fs = require('fs');

fs.readdir(testFolder, function(error, filelist) {
  console.log("./");
  console.log(filelist);
  /* my code
  files.forEach(function{file){
    console.log(file); */
  // });
});


fs.readdir(__dirname, function(error, filelist) {
  console.log("__dirname : "+__dirname);
  console.log(filelist);
  /* my code
  files.forEach(function{file){
    console.log(file); */
  // });
});
