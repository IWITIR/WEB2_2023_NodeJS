var M = {
  v:'v',
  f:function(){
    console.log(this.v);
  },
}

module.exports = M;
// promised statement to export object M (which makes enable to use M on other file, not module mPart.js)
