var args = process.argv; // [0] -> position of node.exe, [1] -> position of compiled file, so [2] would be start
console.log(args[2]);
console.log('A');
console.log('B');
if (args[2] === '1'){
  console.log('C1');
} else if (args[2] === '2'){
  console.log('C2');
} else {
  console.log('NOT both 1 and 2')
}
console.log('D');
