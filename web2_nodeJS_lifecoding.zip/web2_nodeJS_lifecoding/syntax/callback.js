
/*
function a(){
  console.log('A');
}
*/
var a = function(){
  console.log('A');
}
a(); // () calls function in variable a


function slowfunc(callback){ // slowfunc is not callback;
  // it do some preliminary acts.
  console.log('some preliminary things');
  // but it finally calls callback -> we can use asynchronize.
  callback();
}

slowfunc(a);
