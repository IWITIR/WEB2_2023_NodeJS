var fs = require('fs');

//readFileSync (can return)
/*
console.log('A');
var result = fs.readFileSync('syntax/sample.txt', 'utf8');
console.log(result); // B\n and empty line
console.log('C');
*/

//readFile (does not return)
console.log('A');
fs.readFile('syntax/sample.txt', 'utf8', function(err, result) {
  console.log(result); // B\n and empty line
}); // use method function to get result -> callback function.

console.log('C');
