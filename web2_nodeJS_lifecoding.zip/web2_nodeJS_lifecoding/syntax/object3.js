var v1 = 'v1';
var v2 = 'v2';

var o = {
  v1 : 'v1',
  v2 : 'v2',
  f1 : function(){
    console.log(this.v1);
  },
  f2 : function(){
    console.log(this.v2);
  },
}

v1 = 'Ha Ha I intercepted your variable by misunderstanding';

console.log(v1); // haha...
console.log(o.v1); // v1
o.f1(); // v1
o.f2(); // v2
