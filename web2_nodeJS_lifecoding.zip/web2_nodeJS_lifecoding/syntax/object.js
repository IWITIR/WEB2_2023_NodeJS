// array (comparison)
console.log("Array:");


var members = ['egoing', 'k8805', 'hoya'];
console.log(members[1]); // k8805

console.log("---iteration---");

var i = 0;
while(i < members.length){
  console.log(members[i]);
  i += 1;
}

// object
console.log("Object:");

var roles = {
  'programmer' : 'egoing',
  'designer' : 'k8805',
  'manager' : 'hoya',
  func : function(){console.log('func')}
}
console.log(roles.designer); //k8805
roles.func(); // func

console.log("---iteration---");

for (var name in roles){
  console.log(`${name} : ${roles[name]}`); // used roles[name] not roles.name beacuse name is 'string'
  // roles.name -> roles.'programmer' (x)
  // roles[name] -> roles['programmer'] (o)
}
